//
//  NoViewController.swift
//  FinalProject1.2
//
//  Created by user188518 on 12/12/20.
//  Copyright © 2020 user188518. All rights reserved.
//

import UIKit

class NoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

     
    }
    

}
