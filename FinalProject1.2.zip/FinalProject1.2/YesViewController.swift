//
//  YesViewController.swift
//  FinalProject1.2
//
//  Created by user188518 on 12/12/20.
//  Copyright © 2020 user188518. All rights reserved.
//

import UIKit

class YesViewController: UIViewController {

    @IBOutlet weak var Slider1: UISlider!
    @IBOutlet weak var Slider2: UISlider!
    @IBOutlet weak var Slider3: UISlider!
    
    @IBOutlet weak var Label1: UILabel!
    @IBOutlet weak var Label2: UILabel!
    @IBOutlet weak var Label3: UILabel!
    
    
    
    @IBAction func SliderAction(_ sender: Any) {
        
        self.view.backgroundColor = UIColor(red: CGFloat(Slider1.value)/255, green: CGFloat(Slider2.value)/255, blue: CGFloat(Slider3.value)/255, alpha: 1)
        
        Label1.text = String(Slider1.value)
        Label2.text = String(Slider2.value)
        Label3.text = String(Slider3.value)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
